import tkinter
from importlib.resources import contents

from .vfs.vfs import VirtualFileSystem


class ShellEmulator:
    def __init__(self, zip_path, log_path):
        ### GUI
        self.tk = tkinter.Tk()
        self.text = tkinter.Text(self.tk, height=50, width=150, wrap="none", bg="black", fg="white", insertbackground="white", insertwidth=2) # add text widget
        self.text.pack()
        # binds
        self.text.bind("<Return>", self.command)
        self.text.bind("<Up>", lambda e: "break")
        self.text.bind("<Down>", lambda e: "break")
        self.text.bind("<Left>", self.prevent_line_wrap)
        self.text.bind("<Right>", self.prevent_line_wrap)
        self.text.bind("<Home>", lambda e: "break")
        self.text.bind("<End>", lambda e: "break")
        self.text.bind("<Prior>", lambda e: "break")
        self.text.bind("<Next>", lambda e: "break")

        ### VFS
        self.vfs = VirtualFileSystem(zip_path, log_path)

        ### Command history
        self.command_history = []
        self.history_index = 0

    def start(self):
        self.show_path_start_line()
        self.tk.mainloop()

    def command(self, event):
        line = self.text.get("insert linestart", "insert lineend")
        input = line[len(self.vfs.current_dir) + 2:]

        self.text.insert("end", "\n")
        if input.strip():
            should_exit = self.execute_command(input)
            if should_exit:
                self.tk.destroy()
                return "break"
            self.text.insert("end", "\n")

        self.show_path_start_line()
        return "break"

    def execute_command(self, input):
        parts = input.split()
        command = parts[0]
        args = parts[1:] if len(parts) > 1 else []

        if command == "exit":
            return True
        elif command == "cd":
            if len(args) == 1:
                if not self.vfs.cd(args[0]):
                    self.text.insert("end", "Directory not found")
            else:
                self.text.insert("end", "Usage: cd <directory_path>")
        elif command == "ls":
            if len(args) < 2:
                if len(args) == 1:
                    content = self.vfs.ls(args[0])
                else:
                    content = self.vfs.ls()
                k = 0
                for item in content:
                    self.text.insert("end", item)
                    if k != len(content) - 1:
                        self.text.insert("end", " ")
                    k += 1
            else:
                self.text.insert("end", "Usage: ls <path> or nothing")

        return False

    def show_path_start_line(self):
        self.text.insert("end", self.vfs.current_dir + "> ")

    def prevent_line_wrap(self, event):
        current_position = self.text.index("insert")
        line_start = self.text.index("insert linestart")
        prompt_position = self.text.search("> ", line_start, stopindex="insert lineend")

        if prompt_position:
            prompt_end_position = prompt_position + "+2c"
        else:
            prompt_end_position = line_start

        if event.keysym == "Left" and (self.text.compare(current_position, "<=", prompt_end_position)):
            return "break"
        elif event.keysym == "Right" and self.text.compare(current_position, "==", "insert lineend"):
            return "break"

        return None
